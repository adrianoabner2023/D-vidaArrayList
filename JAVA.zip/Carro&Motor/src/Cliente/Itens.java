package Cliente;

import java.util.ArrayList;

public class Itens {

	String nomedoproduto;
	int quantidade;
	double preco;
	
	
	Itens(String nome, int quantidade, double preco){
		
		this.nomedoproduto = nome;
		this.quantidade = quantidade;
		this.preco = preco;
		
		
	}


	public String getNomedoproduto() {
		return nomedoproduto;
	}


	public void setNomedoproduto(String nomedoproduto) {
		this.nomedoproduto = nomedoproduto;
	}


	public int getQuantidade() {
		return quantidade;
	}


	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}


	public double getPreco() {
		return preco;
	}


	public void setPreco(double preco) {
		this.preco = preco;
	}


	


}
